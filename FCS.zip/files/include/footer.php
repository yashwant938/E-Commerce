<?php
if(!defined('app')) {
   die('Direct access not permitted');
}
?>
<footer class="py-3 my-4">
    <ul class="nav justify-content-center border-bottom pb-3 mb-3">
    </ul>
    <p class="text-center text-body-secondary">&copy; 2023 Cyb3rC1ph3r</p>
</footer>