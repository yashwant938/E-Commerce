<?php
date_default_timezone_set('Asia/Kolkata');

class Config
{
     /* 
      const DB_HOST = '192.168.2.248',
      DB_NAME = 'fcs',
      DB_USERNAME = 'cybercipher',
      DB_PASSWORD = 'dbKaP@ssLelo80085',
  ;
  const DB_HOST = 'localhost',
DB_NAME = 'fcs',
DB_USERNAME = 'root',
DB_PASSWORD = '',
*/

const DB_HOST = 'localhost',
DB_NAME = 'fcs',
DB_USERNAME = 'root',
DB_PASSWORD = '',
SERVER_PRIVATE_KEY = 'rX1955rzqSJL',
CCA_WORKING_KEY='5F710BF0ACE10867179275A2A5975BA4',
KEY_ID='rzp_test_B3zurhUSaPfawE',
KET_SECRET='HMKjjaHsWwxioAayKpXmrnvG',
API_LINK='https://192.168.3.39:5000/kyc',
CAPTCHA_SERVER='6LfVhBEpAAAAAOqGNIg3qskIr7avHkP4t6g3R64k',
CAPTCHA_SITE='6LfVhBEpAAAAAAG2gdoEMabMx2N28FQaV98xZzvD'




  ;


} 



