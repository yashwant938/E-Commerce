<?php
if(!defined('app')) {
   die('Direct access not permitted');
}
?>
<h1 style="text-align:center;">Your Account is Disabled</h1>
<div style="text-align:center;">
   <a href="/logout">Logout</a>
</div>